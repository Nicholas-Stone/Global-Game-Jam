﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ReloadGame : MonoBehaviour {
	
	public AudioSource lmao;
	private int timer;

	// Use this for initialization
	void Start () {
		timer = 100;
	}
	
	// Update is called once per frame
	void Update () {
		if(!lmao.isPlaying)
		{
			timer--;
			if(timer < 0)
				SceneManager.LoadScene("Title");
		}
	}
	
	void OnMouseDown()
	{
		
	}
}
